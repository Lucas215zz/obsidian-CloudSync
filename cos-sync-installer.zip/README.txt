Tencent COS Sync — Obsidian 插件安装包
========================================

包含文件：
  main.js                 插件主程序
  manifest.json           插件清单
  styles.css              插件样式
  install-macos.command   macOS 一键安装脚本（双击运行）
  install-windows.bat     Windows 一键安装脚本（双击运行）

使用方法：
  1. 解压本压缩包到任意文件夹
  2. 双击运行对应系统的安装脚本
     - macOS：双击 install-macos.command
     - Windows：双击 install-windows.bat
  3. 脚本会自动找到你的 Obsidian 仓库并安装插件
  4. 完全退出 Obsidian 后重新打开
  5. 在 设置 → 第三方插件 中找到 "Tencent COS Sync" 并启用
  6. 填入腾讯云 COS 配置：SecretId / SecretKey / Bucket / Region

注意：安装脚本会自动将插件加入 community-plugins.json，
无需手动在 Obsidian 设置里开启"启用第三方插件"开关以外的操作。
